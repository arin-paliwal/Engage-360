import Image from 'next/image'
import { Card, CardContent, CardHeader } from '@/components/ui/card'

const testimonials = [
  {
    name: 'Sarah Johnson',
    role: 'HR Director',
    company: 'TechCorp',
    image: '/placeholder.svg?height=100&width=100',
    quote: 'HRFlow has revolutionized our HR processes. It\'s intuitive, powerful, and has saved us countless hours.',
  },
  {
    name: 'Michael Chen',
    role: 'CEO',
    company: 'StartUp Inc.',
    image: '/placeholder.svg?height=100&width=100',
    quote: 'As a fast-growing startup, HRFlow has been instrumental in scaling our HR operations efficiently.',
  },
  {
    name: 'Emily Rodriguez',
    role: 'Employee Experience Manager',
    company: 'Global Enterprises',
    image: '/placeholder.svg?height=100&width=100',
    quote: 'The employee self-service features have greatly improved our overall workplace satisfaction.',
  },
]

export default function Testimonials() {
  return (
    <section id="testimonials" className="py-20 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-center text-gray-900 sm:text-4xl">What Our Clients Say</h2>
        <div className="mt-16 grid gap-8 md:grid-cols-3">
          {testimonials.map((testimonial) => (
            <Card key={testimonial.name} className="bg-gray-50">
              <CardHeader>
                <div className="flex items-center space-x-4">
                  <Image
                    src={testimonial.image}
                    alt={testimonial.name}
                    width={50}
                    height={50}
                    className="rounded-full"
                  />
                  <div>
                    <p className="font-semibold text-gray-900">{testimonial.name}</p>
                    <p className="text-sm text-gray-600">{testimonial.role} at {testimonial.company}</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 italic">&ldquo;{testimonial.quote}&rdquo;</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

