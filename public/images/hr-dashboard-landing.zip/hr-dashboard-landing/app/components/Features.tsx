import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { UserPlus, Calendar, BarChart, FileText } from 'lucide-react'

const features = [
  {
    name: 'Streamlined Onboarding',
    description: 'Automate and simplify the onboarding process for new employees.',
    icon: UserPlus,
  },
  {
    name: 'Leave Management',
    description: 'Effortlessly manage employee leave requests and approvals.',
    icon: Calendar,
  },
  {
    name: 'Performance Analytics',
    description: 'Gain insights into employee performance with advanced analytics.',
    icon: BarChart,
  },
  {
    name: 'Document Management',
    description: 'Securely store and manage all HR-related documents in one place.',
    icon: FileText,
  },
]

export default function Features() {
  return (
    <section id="features" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">Powerful Features for Modern HR</h2>
          <p className="mt-4 text-xl text-gray-600">Everything you need to manage your workforce effectively</p>
        </div>
        <div className="mt-16 grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          {features.map((feature) => (
            <Card key={feature.name} className="bg-white shadow-lg transition-all duration-300 hover:shadow-xl">
              <CardHeader>
                <feature.icon className="h-8 w-8 text-primary" />
                <CardTitle className="text-xl font-semibold">{feature.name}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>{feature.description}</CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

