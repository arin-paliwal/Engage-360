import { Button } from '@/components/ui/button'
import Image from 'next/image'

export default function Hero() {
  return (
    <div className="relative overflow-hidden bg-white py-16 sm:py-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:grid lg:grid-cols-12 lg:gap-8">
          <div className="sm:text-center md:mx-auto md:max-w-2xl lg:col-span-6 lg:text-left">
            <h1 className="text-4xl font-bold tracking-tight text-gray-900 sm:text-5xl md:text-6xl">
              <span className="block xl:inline">Empower Your</span>{' '}
              <span className="block text-primary xl:inline">HR Workflow</span>
            </h1>
            <p className="mt-3 text-base text-gray-500 sm:mt-5 sm:text-xl lg:text-lg xl:text-xl">
              Streamline HR processes, boost employee engagement, and make data-driven decisions with our intuitive HR dashboard.
            </p>
            <div className="mt-8 sm:mt-12">
              <Button size="lg" className="rounded-full">
                Get Started
              </Button>
              <Button variant="outline" size="lg" className="ml-4 rounded-full">
                Watch Demo
              </Button>
            </div>
          </div>
          <div className="relative mt-12 sm:mx-auto sm:max-w-lg lg:col-span-6 lg:mx-0 lg:mt-0 lg:flex lg:max-w-none lg:items-center">
            <div className="relative mx-auto w-full rounded-lg shadow-lg lg:max-w-md">
              <Image
                className="w-full rounded-lg"
                src="/placeholder.svg?height=400&width=600"
                alt="HR Dashboard Preview"
                width={600}
                height={400}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

