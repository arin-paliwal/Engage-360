import Link from 'next/link'
import { Button } from '@/components/ui/button'

export default function Header() {
  return (
    <header className="py-6 px-4 sm:px-6 lg:px-8">
      <div className="container mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="h-8 w-8 text-primary"
          >
            <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
            <circle cx="9" cy="7" r="4" />
            <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
            <path d="M16 3.13a4 4 0 0 1 0 7.75" />
          </svg>
          <span className="text-2xl font-bold text-gray-900">HRFlow</span>
        </div>
        <nav className="hidden md:flex space-x-10">
          <Link href="#features" className="text-base font-medium text-gray-500 hover:text-gray-900">
            Features
          </Link>
          <Link href="#testimonials" className="text-base font-medium text-gray-500 hover:text-gray-900">
            Testimonials
          </Link>
          <Link href="#pricing" className="text-base font-medium text-gray-500 hover:text-gray-900">
            Pricing
          </Link>
        </nav>
        <div className="flex items-center space-x-4">
          <Button variant="outline">Log in</Button>
          <Button>Sign up</Button>
        </div>
      </div>
    </header>
  )
}

