import { Button } from '@/components/ui/button'

export default function CTA() {
  return (
    <section className="bg-primary py-20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-3xl font-bold text-white sm:text-4xl">Ready to Transform Your HR Processes?</h2>
        <p className="mt-4 text-xl text-primary-foreground">
          Join thousands of companies already using HRFlow to streamline their HR operations.
        </p>
        <div className="mt-8">
          <Button size="lg" variant="secondary" className="rounded-full">
            Start Your Free Trial
          </Button>
          <Button size="lg" variant="outline" className="ml-4 rounded-full text-white border-white hover:bg-white hover:text-primary">
            Schedule a Demo
          </Button>
        </div>
      </div>
    </section>
  )
}

